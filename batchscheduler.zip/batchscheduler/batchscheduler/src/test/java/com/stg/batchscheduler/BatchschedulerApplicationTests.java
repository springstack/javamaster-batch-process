package com.stg.batchscheduler;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BatchschedulerApplicationTests {

	@Test
	void contextLoads() {
	}

}
