package com.stg.batchscheduler.batch;

import java.util.Arrays;
import java.util.List;

import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.stg.batchscheduler.entity.BookEntity;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class RestBookReader implements ItemReader<BookEntity>{

	private final String url;
	private final RestTemplate restTemplate;
	private int nextBook;
	private List<BookEntity> bookEntityList;
	
	public RestBookReader(String url, RestTemplate restTemplate) {
		this.restTemplate=restTemplate;
		this.url=url;
	}
	
	@Override
	public BookEntity read() throws Exception {
		log.info("reading the bookData");
		if(this.bookEntityList==null) {
			bookEntityList=fetchBooks();
		}
		BookEntity book=null;
		
		if(nextBook<bookEntityList.size()) {
			book=bookEntityList.get(nextBook);
			nextBook++;
		}
		else {
			nextBook=0;
			bookEntityList=null;
		}
		return book;
	}

	private List<BookEntity> fetchBooks(){
		log.info("fetching the bookData");
		ResponseEntity<BookEntity[]> response = restTemplate.getForEntity(this.url, BookEntity[].class);
		BookEntity[] books=response.getBody();
		if(books!=null) {
			return Arrays.asList(books);
		}
		return null;
	}
	
	
	
	
	
	
	
	
	
}
