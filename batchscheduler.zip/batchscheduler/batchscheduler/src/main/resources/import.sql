insert into book_table(title, author, year_of_publishing) values ('The Great Gatsby', 'F. Scott Fitzgerald', 1925);
insert into book_table(title, author, year_of_publishing) values ('To Kill a Mockingbird', 'Harper Lee', 1960);
insert into book_table(title, author, year_of_publishing) values ('1984', 'George Orwell', 1949);
insert into book_table(title, author, year_of_publishing) values ('Pride and Prejuidice', 'Jane Austen', 1813);
insert into book_table(title, author, year_of_publishing) values ('The Hobbit', 'J.R.R. Tolkien', 1937);
insert into book_table(title, author, year_of_publishing) values ('Brave New World', 'Aldous Huxley', 1932);
insert into book_table(title, author, year_of_publishing) values ('Lord of the Rings: The Fellowship of the Ring', 'J.K. Rowling', 1954);
insert into book_table(title, author, year_of_publishing) values ('Fahrenheit 451', 'Ray Bradbury', 1953);